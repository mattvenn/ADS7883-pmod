\ ![logo](/home/matt/work/finances/mattvenn_logo.png)

# PCB layout for "ads7883 pmod breakout"

\ ![overview](auto-fab/ADS7883-pmod-overview.png)

# Configuration

* 34.1 x 28.1mm
* 1.6 mm FR4, white silkscreen, green mask
* 2 layers, 35um copper
* generated on 2018-07-30 12:29:10.823448, git version cba9d4f
